import Foundation

public fun task(for exercise: String, action: () -> Void) {
    print("ამოცანა: \(exercise)")
    print("----------------------")
    action()
    print()
}
